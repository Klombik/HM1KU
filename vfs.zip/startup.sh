ls
cd home/user
cp /file1.txt /home/user/documents/file2.txt
head /home/user/documents/file2.txt
cd /